----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-09-29 10:44 pm CDT
----------------------------------------------------------------

------------  ----------------------------------------------------------------------  ------------------------
DCOILBRENTEU  Crude Oil Prices: Brent - Europe, Dollars per Barrel, Daily, Not        Data Updated: 2026-09-23
              Seasonally Adjusted
DFF           Federal Funds Effective Rate, Percent, Daily, Not Seasonally Adjusted   Data Updated: 2026-09-29
DFEDTARU      Federal Funds Target Range - Upper Limit, Percent, Daily, Not           Data Updated: 2026-09-29
              Seasonally Adjusted
DTWEXBGS      Nominal Broad U.S. Dollar Index, Index Jan 2006=100, Daily, Not         Data Updated: 2026-09-28
              Seasonally Adjusted
VIXCLS        CBOE Volatility Index: VIX, Index, Daily, Not Seasonally Adjusted       Data Updated: 2026-09-29
DGS10         Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-09-29
              Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
------------  ----------------------------------------------------------------------  ------------------------

